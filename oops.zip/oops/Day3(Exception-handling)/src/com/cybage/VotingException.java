package com.cybage;

public class VotingException extends Exception{

	public VotingException(String msg) {
		super(msg);
		
	}
	
}
