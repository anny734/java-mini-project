package com.hsbc.set;

import java.util.*;

public class SetExample {
	public static void main(String[] args) {
		System.out.println("------ Set Example --------");
//		Set<String> skills = new HashSet<>();
		Set<String> skills = new LinkedHashSet<>();
//		Set<String> skills = new TreeSet<>(); //ascending order
//		Set<String> skills = new TreeSet<>(Collections.reverseOrder());
		
		skills.add("java");
		skills.add("angular");
		skills.add("react");
		skills.add("aws");
		skills.add("java");
		
		System.out.println(skills);
		
		System.out.println(skills.contains("edfw"));
		
	}
}
