package com.example;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository pr;

	@Override
	public List<Product> getProducts() {
		return  pr.findAll();
	}

	@Override
	public Optional<Product> getProductDetails(int id) {
		Optional<Product> product = pr.findById(id);
		return product;
	}

	@Override
	public String addProduct(Product p) {
		pr.save(new Product(p.getId(),p.getName(),p.getPrice(),p.getQuantity()));
		return "sucessfully added";
	}

	@Override
	public String deleteProduct(int id) {
		pr.deleteById(id);
		return "successfully deleted";
	}

	@Override
	public String updateProduct(Product p, int id) {
		pr.save(new Product(p.getId(),p.getName(),p.getPrice(),p.getQuantity()));
		return "sucessfully updated";
	}
	
}
