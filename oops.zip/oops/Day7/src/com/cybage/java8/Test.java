package com.cybage.java8;

import java.util.function.*;

public class Test {
	public static void main(String[] args) {

		// Function 
		BiFunction<Integer, Integer, Integer> cal = (Integer t,Integer u)-> t+u;
			
		System.out.println(cal.apply(10,20));
		
		
		// want to check age
		Predicate<Integer> checkage= (Integer age)->age>18;
		
		System.out.println(checkage.test(2));
		System.out.println(checkage.test(26));
		
		// consumer
		Consumer<String> printer = (String s)->System.out.println("we are using consumer ... "+s); 
		printer.accept("ankit");
		
		// get random number -> supplier
		Supplier<Double> num = ()->Math.random();
		double d= num.get();
		System.out.println(d);
		
		// or
		DoubleSupplier num1 = ()->Math.random();
		System.out.println(num1.getAsDouble());
		
		// function
		DoubleFunction<Double> num2 = (res)->res+1;
		System.out.println("This is double function "+num2.apply(d));
		
		//boolean supplier 	
		double any = Math.random();
		BooleanSupplier b = ()->any>3;
		System.out.println("Number: "+any+" greater than 0 or not =>"+b.getAsBoolean());
	}
}
