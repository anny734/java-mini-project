package com.example;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "RETIRED")
public class Retired extends Employee{
	private int pension;

	public int getPension() {
		return pension;
	}

	public void setPension(int pension) {
		this.pension = pension;
	}

	public Retired() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Retired(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public Retired(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	
	
}
