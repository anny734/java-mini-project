package com.cybage;

import java.io.*;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Second extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Second() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.write("<h1>This is get method(second)</h1>");
		
		ServletContext context = getServletContext();
		System.out.println("organizatiokn name: "+context.getInitParameter("appname"));
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.write("<h1>This is post method(second)</h1>");
		
		String username = request.getParameter("username");
		System.out.println("Username from user(second servlet): "+username);
		
	}

}
