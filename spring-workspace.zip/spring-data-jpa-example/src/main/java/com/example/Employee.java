package com.example;

import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity	
//@Table(name = "emp") //table will be created by this name
//@NamedQuery(name = "Employee.myFindByName", query = "select e from Employee e where e.name = ?1 ") 
//JPQL --> jpa query language, Employee here is entity name not table name
//@NamedNativeQuery(name = "Employee.myFindByName", query = "select * from employee where name = ?1", resultClass = Employee.class)
//native query , here employee in query is table name
public class Employee {
	
	@Id			//this will be primary key 
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name = "myid")
	private int id;

	private String name;
	
	@ElementCollection(fetch = FetchType.EAGER)
	@CollectionTable(name = "emp_phone", joinColumns = @JoinColumn(name = "id"))
	private List<String> phone;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(String name, List<String> phone) {
		super();
		this.name = name;
		this.phone = phone;
	}
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Employee(String name) {
		super();
		this.name = name;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getPhone() {
		return phone;
	}

	public void setPhone(List<String> phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phone=" + phone + "]";
	}
	
	
}
