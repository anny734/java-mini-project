package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@SpringBootApplication
public class SpringDataJpaPageSortingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaPageSortingApplication.class, args);
	}
	//relationship not working properly
	@Autowired
	EmployeeRepository er;
	
	@Autowired
	AccountRepository ar;
	
	
	@Override
	public void run(String... args) throws Exception {
		Account account = new Account("myaccount",null);
		
		Employee emp = new Employee("myname", account);
		
		emp.setAccount(account);
		account.setEmployee(emp);
		
		er.save(emp);
		System.out.println(er.findAll());
		
		
	}

}
