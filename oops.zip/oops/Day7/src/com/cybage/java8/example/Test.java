package com.cybage.java8.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class Test {
	public static void main(String[] args) {
		List<Employee> list = new ArrayList<>();
		
		list.add(new Employee(101,"ankit101",29,1000));
		list.add(new Employee(102,"ankit102",24,2000));
		list.add(new Employee(103,"ankit103",30,3000));
		list.add(new Employee(104,"ankit104",26,4000));
		
		//it will return stream, it will store in temporary
		//sequential 
		list.stream().forEach((e)->System.out.println(e)); 
		
		//parallel 
		list.parallelStream().forEach((e)->System.out.println(e));
		
		// map
		list
		.parallelStream()
		.map((e)->{e.setName(e.getName().toUpperCase());return e;})
		.forEach((e)->System.out.println(e));
		
		System.out.println("------------------------------");
		
		//sort
		list
		.stream()
		.sorted((e1,e2)->e1.getAge()-e2.getAge())
		.forEach((e)->System.out.println(e));
		
		System.out.println("============================");
		//skip and limit
		list
		.stream()
		.skip(1).limit(2)
		.sorted((e1,e2)->e1.getAge()-e2.getAge())
		.forEach((e)->System.out.println(e));
		
		//for first elememt
//		Optional<Employee> first = Optional<>
		System.out.println("first emp is: "+list
				.stream()
				.sorted((e1,e2)->e1.getAge()-e2.getAge())
				.findFirst());

		//filter
		System.out.println("age greater than 30");
		list.stream().filter(e->e.getAge()>=30).forEach(e->System.out.println(e));
		
		//count
		long cnt = list.stream().filter(e->e.getAge()>=30).count();
		System.out.println("no of emp are: "+cnt);
	}
}
