package com.cybage.wrapper;

public class WrapperExample {
	public static void main(String[] args) {
		System.out.println("Wrapper example");
		
		Integer i1 = new Integer(100);
		Integer i2 = 1234; 
		
		
	}
}
