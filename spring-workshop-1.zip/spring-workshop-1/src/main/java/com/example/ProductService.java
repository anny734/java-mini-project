package com.example;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


public interface ProductService {
	public abstract List<Product> getProducts();
	public abstract Optional<Product> getProductDetails(int id);
	public abstract String addProduct(Product p);
	public abstract String deleteProduct(int id);
	public abstract String updateProduct(Product p, int id);
}
