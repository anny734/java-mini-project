package com.cybage;

import java.sql.*;

public class JDBCExample {
	public void getRecord() throws Exception {
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		Statement statement = con.createStatement();
		ResultSet result = statement.executeQuery("select * from customer");
		
		while(result.next()) // will fetch next record
			System.out.println(result.getInt(1)+" "+result.getString(2));
		
		result.close();
		statement.close();
		con.close();
		
	}

	public void addRecord() throws Exception{
		Connection con = DbUtil.getCon();
				
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("insert into customer values (?,?)");
		
		
		ps.setInt(1, 103);
		ps.setString(2, "Eeesha");
				
		if(!ps.execute()) {
			System.out.println("record added succesfully");
		}else {
			System.out.println("not added in  table");
		}
				
		ps.close();
		con.close();
				
				
		
	}

	public void updateRecord() throws Exception{
		Connection con = DbUtil.getCon();
						
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("update customer set name ");
		
	}
}
