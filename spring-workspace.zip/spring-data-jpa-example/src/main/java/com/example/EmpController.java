package com.example;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class EmpController {
	
	@Autowired
	EmployeeRepository er;
	
	//add employee
	@RequestMapping(path = "/employee/{name}", method = RequestMethod.POST)
	@ResponseBody
	public String addEmployee(@PathVariable String name) {
		er.save(new Employee(name));
		return "sucessfully added emp with name: "+name ;
	}
	
	//get employee
	@RequestMapping(path = "/employee", method = RequestMethod.GET)
    @ResponseBody
    public List<Employee> getAllEmployee() {
        return er.findAll();    
    }
	
	//get by id
	@RequestMapping(path = "/employee/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Optional<Employee> getEmployee(@PathVariable int id) {
        return er.findById(id);    
    }
	
	//update 
	@RequestMapping(path = "/employee/{id}/{name}", method = RequestMethod.PUT)
	@ResponseBody
	public String updateEmployee(@PathVariable int id, @PathVariable String name) {
		er.save(new Employee(id, name));
		return "updated record of id: "+ id;
	}
	
	//delete employee
	@RequestMapping(path = "/employee/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public String deleteEmployeeById(@PathVariable int id) {
        er.deleteById(id);
		return "sucessfully deleted emp with id: "+ id;    
    }
	
	//count number of employees
	@RequestMapping("/employee/count")
	@ResponseBody
	public String getCount() {
		return "Total number of employees are: "+ (int)er.count();
	}
	
	//find by name --> named query
	@RequestMapping("/employee/name/{name}")
	@ResponseBody
	public List<Employee> myFindByName(@PathVariable String name) {
		return er.myFindByName(name);
	}
	
	
	
}
