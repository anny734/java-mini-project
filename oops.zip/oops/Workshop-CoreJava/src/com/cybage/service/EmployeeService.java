package com.cybage.service;

public interface EmployeeService{
	public abstract void add(int id,String name, String address, int comp, String type) throws Exception; 
	public abstract void displayAll() throws Exception;
	public abstract void displayComp();
//	public abstract void updateName(int id,String name);
//	public abstract void updateAddress(int id,String address);
//	public abstract void updateComp(int id,String name);
//	public abstract void updateType(int id,String type);
	public abstract void delete(int id) throws Exception;
	public abstract void displayOne(int id) throws Exception;
	public abstract void update(int id, String name, String address, int comp, String type) throws Exception;
	
	
}
