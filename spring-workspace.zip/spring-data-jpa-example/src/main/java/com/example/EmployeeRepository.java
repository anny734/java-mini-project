package com.example;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	//spring data jpa will implement all method related to employee entity
	//crud --> create(save), findAll(), update, delete
	
	@Query(value = "select e from Employee e where e.name = ?1") //jpql will be database independent
	public List<Employee> myFindByName(String name);
	
//	@Query(value = "select * from Employee where name = ?1", nativeQuery = true) //sql will be database dependent
//	public List<Employee> myFindByName(String name);
}
