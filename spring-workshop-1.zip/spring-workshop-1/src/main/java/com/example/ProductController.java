package com.example;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	ProductService ps;
	
	@GetMapping
	@ResponseBody
	public ModelAndView getProducts(){
		List<Product> products = ps.getProducts();
		ModelAndView model = new ModelAndView("/index");
	    model.addObject("products", products);
	    return model;
	}
	@GetMapping(path = "/add")
	public ModelAndView goToAdd() {
		ModelAndView mv = new ModelAndView("addProduct");
		Product product = new Product();
		mv.addObject("product", product);
		return mv;
	}
	
	@PostMapping("/submit-product")
	public String addProduct(@ModelAttribute ("product") Product product){
		ps.addProduct(product);
		return "redirect:/products/";
	}
	
	@GetMapping("/{id}")
	@ResponseBody
	public Optional<Product> getProductDetails(@PathVariable int id) {
		return ps.getProductDetails(id);
	}
	
	@GetMapping("/delete/{id}")
	public String deleteProduct(@PathVariable int id) {
		ps.deleteProduct(id);
		return "redirect:/products/";
	}
	
	@GetMapping("/edit/{id}")
	public ModelAndView updateProduct(@PathVariable int id) {
		ModelAndView mv = new ModelAndView("editProduct");
		Optional<Product> product = ps.getProductDetails(id);
		mv.addObject("product", product);
		return mv;
	}
}
