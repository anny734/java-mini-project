package com.cybage;

import java.io.FileInputStream;
import java.io.IOException;

public class ReadingExample {
	public static void main(String[] args) throws IOException {
		FileInputStream input = null;
		int data = 0;
		
		// program logic
		input = new FileInputStream("myFile.txt");
		while((data = input.read()) != -1) {
			System.out.print((char)data);
		}
		input.close();
		
	}
}
