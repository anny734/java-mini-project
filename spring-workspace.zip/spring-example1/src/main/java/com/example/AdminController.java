package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@GetMapping(path = "/adminhome",produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getAdmin() {
		return "admin";  //htt:localhost:8080/admin/adminhome -> admin.jsp
	}
}
