package com.cybage;
import java.util.*;
public class Voting {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter yor age: ");
		
		int age = sc.nextInt();
		
		try {
			if(age>18) {
				System.out.println("You are eligible for voting");
			}
			else {
				throw new VotingException("not eligible... You age "+age+" is less than 18");
			}
		}catch (VotingException e) {
			System.err.println(e.getMessage());
		}
	}
}
