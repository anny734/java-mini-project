package com.cybage.dao;

import com.cybage.database.*;
import com.cybage.model.Employee;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class EmployeeDaoImpl implements EmployeeDao{
	
	
	@Override
	public void add(Employee emp, String type) throws Exception {
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("insert into employee values (?,?,?,?,?)");
		
		
		ps.setInt(1, emp.getId());
		ps.setString(2, emp.getName());
		ps.setString(3,emp.getAddress());
		ps.setInt(4, emp.getCompensation());
		ps.setString(5, type);
				
		if(!ps.execute()) {
			System.out.println("record added succesfully");
		}else {
			System.out.println("not added in  table");
		}
				
		ps.close();
		con.close();
	}

	@Override
	public void delete(int id) throws Exception{
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("delete from employee where id = ?");
		
		ps.setInt(1, id);
						
		if(!ps.execute()) {
			System.out.println("record deleted succesfully");
		}else {
			System.out.println("record not found");
		}
				
		ps.close();
		con.close();
		
	}

	@Override
	public void display() throws Exception {
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery("select * from employee");
		
		while(result.next()) // will fetch next record
			System.out.println(result.getInt(1)+" "+result.getString(2)+" "+result.getString(3)+" "+result.getInt(4)+" "+result.getString(5));
		
		result.close();
		st.close();
		con.close();
	}

	@Override
	public void displayOne(int id) throws Exception {
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("select * from employee where id = ?");
		ps.setInt(1, id);
		ResultSet result = ps.executeQuery();
		
		while(result.next()) // will fetch next record
			System.out.println(result.getInt(1)+" "+result.getString(2)+" "+result.getString(3)+" "+result.getInt(4)+" "+result.getString(5));
		
		
		result.close();
		ps.close();
		con.close();
		
	}

	@Override
	public void update(int id, String name, String address, int comp, String type) throws Exception {
		Connection con = DbUtil.getCon();
		
		//3. now talk to db trough connection
		PreparedStatement ps = con.prepareStatement("update employee set name = ?, address = ?, salary = ?,category = ? where id = ?");
		ps.setString(1, name);
		ps.setString(2, address);
		ps.setInt(3,comp);
		ps.setString(4, type);
		ps.setInt(5,id);
		
//		int row = ps.executeUpdate(); 
//		System.out.println("no of rows affted : "+row);
		if(ps.executeUpdate() == 1) {
			System.out.println("record updated sccesfully");
		}else {
			System.out.println("not updated in table");
		}
		
		ps.close();
		con.close();
		
	}

}
