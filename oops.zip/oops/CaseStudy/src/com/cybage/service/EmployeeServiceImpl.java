package com.cybage.service;

import java.io.IOException;

import com.cybage.dao.*;
import com.cybage.exception.EmployeeException;
import com.cybage.model.*;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao empDao = new EmployeeDaoImpl(); 
	private Employee emp[] = new Employee[10];
	private static int count = 0;
	// instance initializer executes before constructor
//	{
//		emp[count] = new RegularEmployee(10,"regular","Pune",1000);
//		count++;
//		emp[count] = new RetiredEmployee(11,"retired","Texas",2000);
//		count++;
//	}
	
	
	@Override
	public void add(int id,String name, String address, int comp, String type) throws EmployeeException, IOException{
		
		if(name == "") {
			throw new EmployeeException("Name cannot be empty");
		}
		if(comp <= 0) {
			throw new EmployeeException("Salary should be valid");
		}
		
		if(type == "REG") {
			empDao.add(new RegularEmployee(id, name , address, comp));
			 
			
		}
		if(type == "RET") {
			empDao.add(new RegularEmployee(id, name , address, comp));
		}
	}

	@Override
	public void displayAll() throws IOException {
//		for(Employee e:emp) {
//			if(e == null) 
//				break;
//			System.out.println(e);
//		}
		empDao.display();
	}

	@Override
	public void displayComp() {
		for(Employee e: emp) {
			if(e == null)
				break;
			System.out.println("Id: "+e.getId()+" compensation: "+e.getCompensation());
		}
		
	}

	@Override
	public void updateName(int id, String name) {
		for(Employee e: emp) {
			if(e.getId() == id) {
				e.setName(name);
				System.out.println(e+" name updated");
			}
		}
		
	}

	@Override
	public void updateAddress(int id, String address) {
		for(Employee e: emp) {
			System.out.println("sds");
			if(e.getId() == id) {
				e.setAddress(address);
				System.out.println(e+" address updated");
			}
		}
		
	}

	@Override
	public void updateComp(int id, String name) {
		for(Employee e: emp) {
			if(e.getId() == id) {
//				e.setAddress(address);
				System.out.println(e+" address updated");
			}
		}
		
	}

	@Override
	public void updateType(int id, String type) {
		
		
	}

	@Override
	public void delete(int id) {
		
		
	}
	
	
}
