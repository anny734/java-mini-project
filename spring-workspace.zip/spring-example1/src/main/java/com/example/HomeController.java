package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/user")
public class HomeController {
	@RequestMapping(path = {"/","/index"} , method = RequestMethod.GET)
	public String getIndex() {
		return "index";     // http://localhost:8080/user/index
	}
	
	@GetMapping(path ="/home")
	public String getHome() {
		return "home";     // http://localhost:8080/user/home
	}
	
	@PostMapping(path ="/emp")
//	@RequestMapping(path = "/emp", method = RequestMethod.POST)
	public String getEmp() {
		return "emp";     // http://localhost:8080/user/emp
	}
	
	@GetMapping(path ="/users")
	public String getUser() {
		return "user";      // http://localhost:8080/user/users
	}
	
	@PostMapping(path ="/users")
	public String postUser() {
		return "postuser";      // http://localhost:8080/user/users
	}
	
	// put and delete is in restful application
//	@PutMapping(path ="/users")
//	public String updateUser() {
//		return "updateuser";     
//	}
//	
//	@DeleteMapping(path ="/users")
//	public String deleteUser() {
//		return "deleteuser";     
//	}
}
