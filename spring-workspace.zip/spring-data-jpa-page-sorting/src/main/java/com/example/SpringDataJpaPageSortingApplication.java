package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

@SpringBootApplication
public class SpringDataJpaPageSortingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaPageSortingApplication.class, args);
	}
	
	@Autowired
	EmployeeRepository er;
	
	@Override
	public void run(String... args) throws Exception {
//		er.save(new Employee("ankit", "swimming"));
//		er.save(new Employee("amir", "swimming"));
//		er.save(new Employee("varad", "dancing"));
//		er.save(new Employee("samay", "cricket"));
//		er.save(new Employee("amit", "cricket"));
		
//		System.out.println(er.findByHobbyOrderByNameDesc("swimming"));
//		System.out.println(er.findAllByOrderByNameDesc());
//		System.out.println(er.findAllByOrderByName());
		
//		System.out.println(er.findAll(Sort.by("name")));
//		System.out.println(er.findAll(Sort.by(Sort.Direction.DESC, "name")));
		
		Page<Employee> page = er.findAll(PageRequest.of(2, 4, Sort.by(Sort.Direction.DESC, "hobby")));
//		Page<Employee> page1 = er.findAll(PageRequest.of(1, 4));
		System.out.println(page.getTotalPages());	//total pages
		System.out.println(page.getNumber()); 		//page number(+1 bcoz starting from 0)
		System.out.println(page);					//page details
		System.out.println(page.getContent()); 		//content on that graph
		
		
		System.out.println("-------------------------------------------");
		System.out.println(er.myMethod());
		System.out.println("-------------------------------------------");
		System.out.println(er.myMethod1());
		
		
	}

}
