package com.hsbc.set;

import java.util.*;

public class ProductExample {
	public static void main(String[] args) {
		Set<Product> products = new TreeSet<>();
		
		products.add(new Product(101, "computer", 1000, 15));
		products.add(new Product(108, "laptop", 9000, 15));
		products.add(new Product(104, "mobile", 4000, 15));
		products.add(new Product(101, "computer", 1000, 15));
		
		System.out.println(products);
	}
}
