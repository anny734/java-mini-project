package com.cybage;

import java.io.IOException;

import com.cybage.exception.EmployeeException;
import com.cybage.service.EmployeeService;
import com.cybage.service.EmployeeServiceImpl;

public class EmployeeTest {
	public static void main(String[] args) {
		
		System.out.println("Employee demo");
		
		System.out.println("--------------- Create --------------------");
		EmployeeService empService = new EmployeeServiceImpl();
		try {
			empService.add(200,"reg200","dhule",999,"REG");
		} catch (EmployeeException | IOException  e) {
			System.err.println(e.getMessage());
		}
		try {
			empService.add(201,"ret201","goa",333,"RET");
		} catch (EmployeeException | IOException e) {
			System.err.println(e.getMessage());
		}
		
		System.out.println("--------------- Read --------------------");
		try {
			empService.displayAll();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
//		empService.displayComp();
//		
//		System.out.println("--------------- Update --------------------");
//		empService.updateName(11, "Snehal");
//		empService.updateAddress(12, "Ohio");
//		
//		System.out.println("--------------- Delete --------------------");
//		
		
	}
}
