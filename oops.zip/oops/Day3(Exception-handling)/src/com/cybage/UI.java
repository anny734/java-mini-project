package com.cybage;

import java.util.*;
//import java.util.Scanner;


public class UI {
	public static void main(String[] args) {
		System.out.println("---------- Exception handling -------------");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter 2 numbers");
		int n1 = scanner.nextInt();
		int n2 = scanner.nextInt();
		
		try {
			int div = n1/n2;
			System.out.println("Division: "+div);
		}catch(ArithmeticException e) {
			System.err.println(e.getMessage()); // for developer
			System.err.println("Please enter valid number ");
		}finally {
			System.out.println("finally block");
			scanner.close();
		}
		
	}
}
;