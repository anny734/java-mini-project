package com.cybage.characterstream;
import java.io.*;

public class WritingExample {
	public static void main(String[] args) throws IOException {
		FileWriter writer = null;
		String data = "this is write in filewriter ";
		writer = new FileWriter("character.txt");
		writer.write(data);
		writer.close();
	}
}
