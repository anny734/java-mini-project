package com.cybage;
import java.io.*;

public class WritingExample {
	public static void main(String[] args) throws IOException {
		// variables
		FileOutputStream output = null;
		String data = "i want to write this in file";
		// program logic
		try {
			output = new FileOutputStream("myFile.txt",true);
			output.write(data.getBytes());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			output.close();
		}
		
	}
}
