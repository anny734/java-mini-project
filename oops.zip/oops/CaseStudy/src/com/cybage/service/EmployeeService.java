package com.cybage.service;

import java.io.IOException;

import com.cybage.exception.EmployeeException;

public interface EmployeeService{
	public abstract void add(int id,String name, String address, int comp, String type) throws EmployeeException, IOException; 
	public abstract void displayAll() throws IOException;
	public abstract void displayComp();
	public abstract void updateName(int id,String name);
	public abstract void updateAddress(int id,String address);
	public abstract void updateComp(int id,String name);
	public abstract void updateType(int id,String type);
	public abstract void delete(int id);
	
}
