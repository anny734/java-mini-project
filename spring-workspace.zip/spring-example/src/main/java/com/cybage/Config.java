//package com.cybage;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration // this class is used for configuration
//public class Config {
//	
//	@Bean(name = "emp")
//	public Employee getEmp() {
//		return new Employee(101,"ankit sonje");
//	}
//	
//	@Bean(name = "emp1")
//	public Employee getEmp1() {
//		return new Employee(102,"kunal kundal");
//	}
//}
