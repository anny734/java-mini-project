package com.cybage.map;

import java.util.HashMap;
import java.util.Map;

public class MapExample {
	public static void main(String[] args) {
		System.out.println("----------- Map Example ---------------");
		Map<String, String> capitals = new HashMap<>();
		
	}
}
