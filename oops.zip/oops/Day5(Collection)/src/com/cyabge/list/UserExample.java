package com.cyabge.list;

import java.util.*;

public class UserExample {
	public static void main(String[] args) {
		System.out.println("user example");
		
		List<User> users = new ArrayList<>();
		
		users.add(new User(101,"ram"));
		users.add(new User(105,"sham"));
		users.add(new User(109,"ajay"));
		users.add(new User(104,"raj"));
		
		System.out.println("--------------------\n"+users);
		
		//remove object
		users.remove(new User(102,"sham"));
		System.out.println("After removal: "+users);
		
		//sorting
		Collections.sort(users);
		System.out.println("After sorting: "+users);
		
		 //sorting using id(asc)
        Collections.sort(users, new IdComparator());
        System.out.println("after sorting" + users);
        
        //now i want to sorting using id but in desc
        Collections.sort(users, new IdComparatorDesc());
        System.out.println("after sorting id desecnding" + users);
        
        //now want to sort using name(Asc)
        Collections.sort(users, new NameComparator());
        System.out.println("after sorting name ascending" + users);
		
      //now want to sort using name(desc)
        Collections.sort(users, new NameComparatorDesc());
        System.out.println("after sorting name descending" + users);
	}
}
