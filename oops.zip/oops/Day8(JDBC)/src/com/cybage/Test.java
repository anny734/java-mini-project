package com.cybage;

public class Test {
	public static void main(String[] args) {
		System.out.println("Jdbc example");
		JDBCExample db = new JDBCExample();
		try {
			db.getRecord();
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

		try {
			db.updateRecord();
		} catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
	
	
	}
}
