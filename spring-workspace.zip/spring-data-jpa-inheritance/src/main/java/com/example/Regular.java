package com.example;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "REGULAR")
public class Regular extends Employee{
	private int salary;

	public Regular() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Regular(int id, String name) {
		super(id, name);
		// TODO Auto-generated constructor stub
	}

	public Regular(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
}
