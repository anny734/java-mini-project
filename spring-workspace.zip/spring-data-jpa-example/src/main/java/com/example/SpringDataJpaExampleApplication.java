package com.example;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaExampleApplication implements CommandLineRunner{
	
	@Autowired
	EmployeeRepository er;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExampleApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
//		List<String> phone = new ArrayList<>();
//		phone.add("54524");
//		phone.add("832865");
//		phone.add("54838963524");
//		phone.add("453");
//		phone.add("3333424");
//		
//		er.save(new Employee("tanmay",phone));
		
		System.out.println("-----------------");
		System.out.println(er.findAll());
		
	}

}
