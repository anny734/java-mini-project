package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FormController {
	
	@RequestMapping(path = "/showform")
	public String showForm(Model model) {
//		System.out.println(10/0);
		Employee emp = new Employee(101,"ankit"); //default values
		model.addAttribute("emp", emp);
		return "show-form";
	}
	
	
		
}
