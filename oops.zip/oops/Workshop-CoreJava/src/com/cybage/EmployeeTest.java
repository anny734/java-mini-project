package com.cybage;

import java.io.IOException;
import java.util.Scanner;

import com.cybage.exception.EmployeeException;
import com.cybage.service.EmployeeService;
import com.cybage.service.EmployeeServiceImpl;

public class EmployeeTest {
	public static void main(String[] args) {
		int choice,id,salary;
		String name, address,type;
		System.out.println("Employee demo");
		EmployeeService empService = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("----------------- Workshop ----------------------\n"
				+ "1. Add\n2. Display All\n3. Display using id\n4. Update\n5. Delete\n6. Exit\n");
		System.out.println("Please enter yor choice: ");
		choice= sc.nextInt();
		try {
			
		switch(choice) {
			case 1:
				System.out.println("Enter details of employee.\nId: ");
				id = sc.nextInt();
				System.out.println("Name: ");
				name = sc.next();
				System.out.println("Address: ");
				address = sc.next();
				System.out.println("Salary: ");
				salary = sc.nextInt();
				System.out.println("Regular or Retired employee: 'REG' or 'RET' ");
				type = sc.next();
				empService.add(id,name,address,salary,type);
				break;
			
			case 2:
				empService.displayAll();
				break;
			case 3:
				empService.displayOne(200);
				break;
			case 4:
				System.out.println("Enter details of employee.\nId: ");
				id = sc.nextInt();
				System.out.println("Name: ");
				name = sc.next();
				System.out.println("Address: ");
				address = sc.next();
				System.out.println("Salary: ");
				salary = sc.nextInt();
				System.out.println("Regular or Retired employee: 'REG' or 'RET' ");
				type = sc.next();
				empService.update(id,name,address,salary,type);
				break;
			case 5:
				System.out.println("Enter id: ");
				id = sc.nextInt();
				empService.delete(id);
				break;
			case 6:
				break;
			default:
				System.exit(0);
				
		}	
		} catch (Exception     e) {
			System.err.println(e.getMessage());
		}
	
	}
}
