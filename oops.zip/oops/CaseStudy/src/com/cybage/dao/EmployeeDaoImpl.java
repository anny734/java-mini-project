package com.cybage.dao;

import com.cybage.model.Employee;

import java.io.*;

public class EmployeeDaoImpl implements EmployeeDao{
	
	FileWriter writer = null;
	FileReader reader = null;
	
	// create file
	{
		try {
			writer = new FileWriter("db.txt",true);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} 
		try {
			reader = new FileReader("db.txt");
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void add(Employee emp) throws IOException {
		writer.write(emp.toString());
		writer.close();
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display() throws IOException {
		reader.read();
		reader.close();
	}

}
