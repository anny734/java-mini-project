package com.cyabge.list;

import java.util.*;

public class ListExample {
	public static void main(String[] args) {
		List <String> skills = new ArrayList<>();
		
		skills.add("html");
		skills.add("css");
		skills.add("java");
		skills.add("css");//duplication allowed
		
		skills.add(0, "react");
		skills.add(3, "rwd");
		
		//option 1
		System.out.println("------------ 1. using sysout---------------");
		System.out.println(skills);
		
		//remove element
		skills.remove(1);
		//remove using object
		skills.remove("css");
		

		//option 2
		System.out.println("------------ 2. using for each ---------------");
		for(String s: skills) {
			System.out.println(s);
		}
		
		//searching
		System.out.println("serach using index: "+skills.get(2));
		// searching using object
		System.out.println("serch using object: "+skills.contains("rwd"));
		//search using index
		System.out.println("index of object "+skills.lastIndexOf("css"));
		
		//sort
		Collections.sort(skills);
		System.out.println("after sorting "+skills);
		//sort descending
		Collections.sort(skills,Collections.reverseOrder());
		System.out.println("reverse order:"+skills);
		
		//option 3
		System.out.println("------------ 3. using iterator ---------------");
		Iterator<String> skillIterator = skills.iterator();
		while(skillIterator.hasNext()) {
			System.out.println(skillIterator.next());
		}
		
		System.out.println("\nsize of arraylist: "+skills.size());
		
		
	}
}
